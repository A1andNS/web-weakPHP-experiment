<?php
    include('./config.php');
    if (isset($_POST['Username']) && isset($_POST['password'])) {
        $logined = true;
        $Username = $_POST['Username'];
        $password = $_POST['password'];

        if (!ctype_alpha($Username)) {$logined = false;}
        if (!is_numeric($password) ) {$logined = false;}
        if (md5($Username) != md5($password)) {$logined = false;}
        if ($logined){
            echo "<script language='JavaScript' type='text/javascript'>";
            echo "alert('Good Job!flag1:".$flag1."');";
            echo "window.location.href='./level2.html';";
            echo "</script>";
        }
        else{
            echo "<script language='JavaScript' type='text/javascript'>";
            echo "alert('login failed!My account number is pure letter, my password is pure number, but md5(account number)==md5(password).');";
            echo "window.location.href='./index.html';";
            echo "</script>";
        }
    }
    else{
        echo "<script language='JavaScript' type='text/javascript'>";
        echo "alert('You have to enter something！');";
        echo "window.location.href='./index.html';";
        echo "</script>";
    }

?>
