<?php
    include('./config.php');
    $password = "n0_0n3_c@n_93t_my_f1a9";
    if (isset($_POST['password'])) {
        if (strcmp($_POST['password'], $password) == 0) {
            echo "<script language='JavaScript' type='text/javascript'>";
            echo "alert('Good Job!flag3:" . $flag3 . "');";
            echo "window.location.href='./answer.html';";
            echo "</script>";
        } else {
            echo "<script language='JavaScript' type='text/javascript'>";
            echo "alert('wrong password!!!');";
            echo "window.location.href='./level3.html';";
            echo "</script>";
        }
    }
    else{
        echo "<script language='JavaScript' type='text/javascript'>";
        echo "alert('You have to enter something！');";
        echo "window.location.href='./level3.html';";
        echo "</script>";
    }
?>