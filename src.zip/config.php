<?php
    $flag1 = "flag{1289fa8a";
    $flag2 = "da2f7272";
    $flag3 = "6cbd0e5b7dc5ed81}";
    $flag = "flag{1289fa8ada2f72726cbd0e5b7dc5ed81}";
?>