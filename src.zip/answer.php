<?php
    include('./config.php');
    if (isset($_POST['stunum'])&&isset($_POST['flag'])){
        $stunum = $_POST['stunum'];
        $stu_flag = $_POST['flag'];
        if ($stu_flag === $flag) {
            echo "<h1 align='center'>你的学号是:".$stunum."</h1>";
            echo "</br>";
            echo "<h1 align='center'>你的flag是:".$stu_flag."</h1>";
            echo "<script language='JavaScript' type='text/javascript'>";
            echo "alert('Your flag is right, congratulations!!!');";
            echo "</script>";
        }
        else{
            echo "<script language='JavaScript' type='text/javascript'>";
            echo "alert('Wrong flag');";
            echo "window.location.href='./answer.html';";
            echo "</script>";
        }
    }
    else{
        echo "<script language='JavaScript' type='text/javascript'>";
        echo "alert('You have to enter something！');";
        echo "window.location.href='./index.html';";
        echo "</script>";
    }

