<?php
    include('./config.php');
    if (isset($_POST['message'])) {
        $message = json_decode($_POST['message']);
        $key ="admin_is_good";
        if ($message->key == $key) {
            echo "<script language='JavaScript' type='text/javascript'>";
            echo "alert('Good Job!flag2:".$flag2."');";
            echo "window.location.href='./level3.html';";
            echo "</script>";
        }
        else {
            echo "<script language='JavaScript' type='text/javascript'>";
            echo "alert('fail!!!');";
            echo "window.location.href='./level2.html';";
            echo "</script>";
        }
    }
    else{
        echo "<script language='JavaScript' type='text/javascript'>";
        echo "alert('You have to enter something！');";
        echo "window.location.href='./level2.html';";
        echo "</script>";
    }
?>